# -*- coding: utf-8 -*-


free = '.'
reserved = 'O'
seats = free * 3 + free * 13 + free * 3

def checkSeats(seats, num):
    return free * (6 + num) in seats
    
while(True):
    cmd = input('Possible commands are: ?[number], +[number], s, q\n')
    
    if (cmd.startswith('?')):
        try:
            num = int(cmd[1:])
            if (num <= 0 or num > 4):
                raise ValueError
            if (checkSeats(seats, num)):
                print('yes')
            else:
                print('no')
        except ValueError:
            print('please enter a whole number from 1 to 4')
    elif (cmd.startswith('+')):
        try:
            num = int(cmd[1:])
            if (num <= 0 or num > 4):
                raise ValueError
            if (checkSeats(seats, num)):
                seats = seats.replace(free * (6 + num), 
                                      free * 3 + reserved * num + free * 3,
                                      1)
                print('assigned')
            else:
                print('failed')
        except ValueError:
            print('please enter a whole number from 1 to 4')
    elif (cmd == 's'):
        print(seats[3:-3])
    elif (cmd == 'q'):
        break
    else:
        print('command could not be parsed')









