# -*- coding: utf-8 -*-


free = '.'
reserved = 'O'
seats = [free * 3 + free * 13 + free * 3] * 5

def freeRows(seats, num):
    return [i for i in range(5) if (free * (6 + num) in seats[i])]

def parseNum(cmd):
    try:
        num = int(cmd[1:])
        if (num <= 0 or num > 4):
            raise ValueError
        return num
    except ValueError:
        print('please enter a whole number from 1 to 4')
        return -1
    
while(True):
    cmd = input('Possible commands are: ?[number], +[number], s, q\n')
    
    if (cmd.startswith('?')):
        num = parseNum(cmd)
        if (num == -1):
            continue
        if any([free * (6 + num) in row for row in seats]):
            print('yes')
        else:
            print('no')
    elif (cmd.startswith('+')):
        num = parseNum(cmd)
        if (num == -1):
            continue
        freeRows = freeRows(seats, num)
        if (freeRows):
            seats[freeRows[0]] = seats[freeRows[0]].replace(free * (6 + num), 
                                                            free * 3 + reserved * num + free * 3,
                                                            1)
            print('assigned')
        else:
            print('failed')
    elif (cmd == 's'):
        for row in seats:
            print(row[3:-3])
    elif (cmd == 'q'):
        break
    else:
        print('command could not be parsed')









